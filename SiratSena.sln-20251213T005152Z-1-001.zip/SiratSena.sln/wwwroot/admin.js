﻿document.addEventListener("DOMContentLoaded", cargarReportes);

async function cargarReportes() {
    try {
        let respuesta = await fetch(API + "accidente/listar");
        let data = await respuesta.json();

        let contenedor = document.getElementById("lista-reportes");
        contenedor.innerHTML = "";

        data.forEach(r => {
            contenedor.innerHTML += `
                <div class="tarjeta">
                    <div class="info">
                        <p><b>Fecha:</b> ${r.fecha}</p>
                        <p><b>Hora:</b> ${r.hora}</p>
                        <p><b>Gravedad:</b> ${r.gravedad}</p>
                        <p><b>Descripción:</b> ${r.descripcion}</p>
                        <p><b>Estudiante:</b> ${r.estudianteNombre}</p>
                    </div>
                </div>
            `;
        });

    } catch (e) {
        alert("Error cargando reportes");
    }
}
