﻿function irReporte() {
    window.location.href = "reporte.html";
}

async function verMisReportes() {
    let usuario = obtenerUsuario();

    window.location.href = "ver-reportes-est.html?id=" + usuario.ID_ESTUDIANTE;
}

document.addEventListener("DOMContentLoaded", cargarMisReportes);

async function cargarMisReportes() {
    let params = new URLSearchParams(window.location.search);
    let id = params.get("id");

    if (!id) return;

    try {
        let respuesta = await fetch(API + "accidente/por-estudiante/" + id);
        let data = await respuesta.json();

        let cont = document.getElementById("mis-reportes");
        cont.innerHTML = "";

        data.forEach(r => {
            cont.innerHTML += `
                <div class="tarjeta">
                    <div class="info">
                        <p><b>Fecha:</b> ${r.fecha}</p>
                        <p><b>Hora:</b> ${r.hora}</p>
                        <p><b>Gravedad:</b> ${r.gravedad}</p>
                        <p><b>Descripción:</b> ${r.descripcion}</p>
                    </div>
                </div>
            `;
        });

    } catch (e) {
        alert("Error cargando reportes");
    }
}
