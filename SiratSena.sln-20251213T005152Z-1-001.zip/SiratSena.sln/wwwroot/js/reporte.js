﻿async function enviarReporte() {
    let usuario = obtenerUsuario();

    let reporte = {
        ID_ESTUDIANTE: usuario.ID_ESTUDIANTE,
        Fecha: document.getElementById("fecha").value,
        Hora: document.getElementById("hora").value,
        Gravedad: document.getElementById("gravedad").value,
        Descripcion: document.getElementById("descripcion").value,
        ID_ACCIDENTES_REPORTADOS: 1   // TEMPORAL
    };

    try {
        let respuesta = await fetch(API + "accidente/crear", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(reporte)
        });

        if (!respuesta.ok) {
            alert("No se pudo enviar el reporte");
            return;
        }

        alert("Reporte enviado");
        window.location.href = "panel-estudiante.html";

    } catch (e) {
        alert("Error en el servidor");
    }
}
