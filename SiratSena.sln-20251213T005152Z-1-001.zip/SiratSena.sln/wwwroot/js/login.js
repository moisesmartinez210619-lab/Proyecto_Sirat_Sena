﻿async function login() {
    let correo = document.getElementById("correo").value.trim();
    let clave = document.getElementById("contrasena").value.trim();

    if (correo === "" || clave === "") {
        alert("Todos los campos son obligatorios");
        return;
    }

    // ADMIN ESPECIAL
    if (correo === "siratadmin@gmail.com") {
        await loginAdmin(correo, clave);
        return;
    }

    // LOGIN ESTUDIANTE
    await loginEstudiante(correo, clave);
}

async function loginEstudiante(correo, clave) {
    try {
        let respuesta = await fetch(API + "auth/login-estudiante", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ correo, contrasena: clave })
        });

        if (!respuesta.ok) {
            alert("Correo o contraseña incorrectos");
            return;
        }

        let data = await respuesta.json();
        guardarUsuario(data.datos, "estudiante");

        window.location.href = "panel-estudiante.html";

    } catch (e) {
        alert("Error en el servidor");
    }
}

async function loginAdmin(correo, clave) {
    try {
        let respuesta = await fetch(API + "auth/login-admin", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ correo, contrasena: clave })
        });

        if (!respuesta.ok) {
            alert("Datos incorrectos de administrador");
            return;
        }

        let data = await respuesta.json();
        guardarUsuario(data.datos, "admin");

        window.location.href = "panel-admin.html";

    } catch (e) {
        alert("Error en el servidor");
    }
}
