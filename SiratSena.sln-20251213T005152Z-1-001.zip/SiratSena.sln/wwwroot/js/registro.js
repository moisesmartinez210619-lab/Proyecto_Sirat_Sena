﻿async function registrar() {
    let nombre = document.getElementById("nombre").value.trim();
    let apellido = document.getElementById("apellido").value.trim();
    let correo = document.getElementById("correo").value.trim();
    let contrasena = document.getElementById("contrasena").value.trim();

    if (nombre === "" || apellido === "" || correo === "" || contrasena === "") {
        alert("Todos los campos son obligatorios");
        return;
    }

    try {
        let respuesta = await fetch(API + "auth/registrar-estudiante", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ nombre, apellido, correo, contrasena })
        });

        if (!respuesta.ok) {
            alert("No se pudo registrar. El correo puede estar en uso.");
            return;
        }

        alert("Registro exitoso. Ahora puedes iniciar sesión.");
        window.location.href = "index.html";

    } catch (e) {
        alert("Error en el servidor");
    }
}
