﻿const API = "https://localhost:57450/api/Auth";
const API_ACCIDENTES = "https://localhost:57450/api/Accidente";

// LOGIN UNIVERSAL
async function login() {
    const correo = document.getElementById("correo").value;
    const clave = document.getElementById("clave").value;

    const datos = { correo, clave };

    // ADMIN
    let admin = await fetch(`${API}/LoginAdmin`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(datos)
    });

    if (admin.ok) {
        let data = await admin.json();
        localStorage.setItem("admin", JSON.stringify(data));
        location.href = "admin_dashboard.html";
        return;
    }

    // ESTUDIANTE
    let est = await fetch(`${API}/LoginEstudiante`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(datos)
    });

    if (est.ok) {
        let data = await est.json();
        localStorage.setItem("estudiante", JSON.stringify(data));
        location.href = "estudiante_dashboard.html";
        return;
    }

    alert("Credenciales incorrectas.");
}


// Navegación
function irAReportarAccidente() {
    location.href = "reportar_accidente.html";
}

function verAccidentesAdmin() {
    location.href = "ver_accidentes_admin.html";
}

function verAccidentesEst() {
    location.href = "ver_accidentes_estudiante.html";
}

function volverAdmin() {
    location.href = "admin_dashboard.html";
}

function volverEstudiante() {
    location.href = "estudiante_dashboard.html";
}

// Cerrar Sesión
function cerrarSesion() {
    localStorage.clear();
    location.href = "index.html";
}

// Reportar Accidente
async function reportarAccidente() {
    let est = JSON.parse(localStorage.getItem("estudiante"));
    if (!est) { alert("Debes iniciar sesión."); return; }

    const datos = {
        descripcion: document.getElementById("descripcion").value,
        gravedad: document.getElementById("gravedad").value,
        imagen: document.getElementById("imagen").value,
        fecha: new Date().toISOString().split("T")[0],
        hora: new Date().toLocaleTimeString(),
        id_ESTUDIANTE: est.id,
        id_ACCIDENTES_REPORTADOS: 1
    };

    let res = await fetch(API_ACCIDENTES, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(datos)
    });

    if (res.ok) alert("Accidente reportado correctamente.");
    else alert("Error al reportar accidente.");
}


// Obtener accidentes del Admin
async function cargarAccidentesAdmin() {
    let res = await fetch(API_ACCIDENTES);
    let lista = await res.json();

    let div = document.getElementById("listaAccidentes");
    div.innerHTML = "";

    lista.forEach(acc => {
        div.innerHTML += `
            <p><strong>${acc.descripcion}</strong><br>
            Gravedad: ${acc.gravedad}<br>
            Estudiante: ${acc.estudianteId}</p><hr>
        `;
    });
}

if (location.pathname.includes("ver_accidentes_admin.html")) {
    cargarAccidentesAdmin();
}

// Obtener accidentes del Estudiante
async function cargarAccidentesEst() {
    let est = JSON.parse(localStorage.getItem("estudiante"));

    let res = await fetch(`${API_ACCIDENTES}/ByEstudiante/${est.id}`);
    let lista = await res.json();

    let div = document.getElementById("listaAccidentes");
    div.innerHTML = "";

    lista.forEach(acc => {
        div.innerHTML += `
            <p><strong>${acc.descripcion}</strong><br>
            Gravedad: ${acc.gravedad}</p><hr>
        `;
    });
}

if (location.pathname.includes("ver_accidentes_estudiante.html")) {
    cargarAccidentesEst();
}
