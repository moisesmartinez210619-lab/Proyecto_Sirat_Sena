﻿const API = "https://localhost:57450/api/";

// -------------------------------------------
// FUNCIONES ÚTILES
// -------------------------------------------

function guardarUsuario(usuario, tipo) {
    localStorage.setItem("usuario", JSON.stringify(usuario));
    localStorage.setItem("tipo", tipo);
}

function obtenerUsuario() {
    return JSON.parse(localStorage.getItem("usuario"));
}

function obtenerTipo() {
    return localStorage.getItem("tipo");
}

function cerrarSesion() {
    localStorage.clear();
    window.location.href = "index.html";
}
