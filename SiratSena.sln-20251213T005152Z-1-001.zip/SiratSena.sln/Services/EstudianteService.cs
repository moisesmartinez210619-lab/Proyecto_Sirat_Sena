using Microsoft.EntityFrameworkCore;
using SiratSena.Data;
using SiratSena.Models;

namespace SiratSena.Services
{
    public class EstudianteService
    {
        private readonly AppDbContext _context;

        public EstudianteService(AppDbContext context)
        {
            _context = context;
        }

        // Obtener todos
        public async Task<List<Estudiante>> GetAll()
        {
            return await _context.Estudiantes
                .Include(e => e.InfoEducacion)
                .ToListAsync();
        }

        // Obtener por ID
        public async Task<Estudiante?> GetById(int id)
        {
            return await _context.Estudiantes
                .Include(e => e.InfoEducacion)
                .FirstOrDefaultAsync(e => e.ID_ESTUDIANTE == id);
        }

        // Crear
        public async Task<Estudiante> Create(Estudiante estudiante)
        {
            _context.Estudiantes.Add(estudiante);
            await _context.SaveChangesAsync();
            return estudiante;
        }

        // Actualizar
        public async Task<bool> Update(int id, Estudiante updated)
        {
            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.ID_ESTUDIANTE == id);

            if (estudiante == null)
                return false;

            estudiante.Nombre = updated.Nombre;
            estudiante.Apellido = updated.Apellido;
            estudiante.Correo = updated.Correo;
            estudiante.ID_INFO_EDUCACION = updated.ID_INFO_EDUCACION;

            await _context.SaveChangesAsync();
            return true;
        }

        // Eliminar
        public async Task<bool> Delete(int id)
        {
            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.ID_ESTUDIANTE == id);

            if (estudiante == null)
                return false;

            _context.Estudiantes.Remove(estudiante);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
