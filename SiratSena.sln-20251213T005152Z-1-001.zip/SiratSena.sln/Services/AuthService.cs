using Microsoft.EntityFrameworkCore;
using SiratSena.Data;
using SiratSena.Models;

namespace SiratSena.Services
{
    public class AuthService
    {
        private readonly AppDbContext _context;

        public AuthService(AppDbContext context)
        {
            _context = context;
        }

        // ============================================================
        //  LOGIN ESTUDIANTE
        // ============================================================
        public async Task<object?> LoginEstudiante(string correo, string clave)
        {
            var login = await _context.InicioSesionEstudiante
                .Where(l => l.Correo == correo && l.Contrasena == clave)
                .Join(
                    _context.Estudiantes,
                    s => s.ID_ESTUDIANTE,
                    e => e.ID_ESTUDIANTE,
                    (s, e) => new
                    {
                        e.ID_ESTUDIANTE,
                        e.Nombre,
                        e.Apellido,
                        e.Correo
                    }
                )
                .FirstOrDefaultAsync();

            // Si existe, actualizar �ltimo acceso
            if (login != null)
            {
                var sesion = await _context.InicioSesionEstudiante
                    .FirstOrDefaultAsync(x => x.Correo == correo);

                if (sesion != null)
                {
                    sesion.Ultimo_Acceso = DateTime.Now;
                    await _context.SaveChangesAsync();
                }
            }

            return login;
        }

        // ============================================================
        //  LOGIN ADMIN
        // ============================================================
        public async Task<object?> LoginAdmin(string correo, string clave)
        {
            var login = await _context.InicioSesionAdmin
                .Where(l => l.Correo == correo && l.Contrasena == clave)
                .Join(
                    _context.Admins,
                    s => s.ID_ADMIN,
                    a => a.ID_ADMIN,
                    (s, a) => new
                    {
                        a.ID_ADMIN,
                        a.Nombre_Admin,
                        a.Correo
                    }
                )
                .FirstOrDefaultAsync();

            if (login != null)
            {
                var sesion = await _context.InicioSesionAdmin
                    .FirstOrDefaultAsync(x => x.Correo == correo);

                if (sesion != null)
                {
                    sesion.Ultimo_Acceso = DateTime.Now;
                    await _context.SaveChangesAsync();
                }
            }

            return login;
        }

        // ============================================================
        //  REGISTRO ESTUDIANTE
        // ============================================================
        public async Task<bool> RegistrarEstudiante(string correo, string contrasena, string nombre, string apellido)
        {
            // Validar si el correo ya existe
            var existe = await _context.InicioSesionEstudiante
                .AnyAsync(x => x.Correo == correo);

            if (existe)
                return false;

            // Crear estudiante
            var nuevoEstudiante = new Estudiante
            {
                Nombre = nombre,
                Apellido = apellido,
                Correo = correo,
                ID_INFO_EDUCACION = null
            };

            _context.Estudiantes.Add(nuevoEstudiante);
            await _context.SaveChangesAsync();

            // Crear ingreso de sesi�n
            var nuevaSesion = new InicioSesionEstudiante
            {
                Correo = correo,
                Contrasena = contrasena,
                Fecha_Registro = DateTime.Now,
                Ultimo_Acceso = DateTime.Now,
                ID_ESTUDIANTE = nuevoEstudiante.ID_ESTUDIANTE
            };

            _context.InicioSesionEstudiante.Add(nuevaSesion);
            await _context.SaveChangesAsync();

            return true;
        }
    }
}
