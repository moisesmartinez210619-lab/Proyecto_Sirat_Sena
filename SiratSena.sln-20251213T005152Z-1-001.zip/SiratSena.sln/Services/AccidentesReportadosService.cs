﻿using Microsoft.EntityFrameworkCore;
using SiratSena.Data;
using SiratSena.Models;

namespace SiratSena.Services
{
    public class AccidentesReportadosService
    {
        private readonly AppDbContext _context;

        public AccidentesReportadosService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<AccidentesReportados>> GetAll()
        {
            return await _context.AccidentesReportados.ToListAsync();
        }

        public async Task<AccidentesReportados?> GetById(int id)
        {
            return await _context.AccidentesReportados
                .FirstOrDefaultAsync(a => a.ID_ACCIDENTES_REPORTADOS == id);
        }

        public async Task<AccidentesReportados> Create(AccidentesReportados reporte)
        {
            _context.AccidentesReportados.Add(reporte);
            await _context.SaveChangesAsync();
            return reporte;
        }

        public async Task<bool> Update(int id, AccidentesReportados updated)
        {
            var reporte = await _context.AccidentesReportados
                .FirstOrDefaultAsync(a => a.ID_ACCIDENTES_REPORTADOS == id);

            if (reporte == null)
                return false;

            reporte.Accidente_Reporte = updated.Accidente_Reporte;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> Delete(int id)
        {
            var reporte = await _context.AccidentesReportados
                .FirstOrDefaultAsync(a => a.ID_ACCIDENTES_REPORTADOS == id);

            if (reporte == null)
                return false;

            _context.AccidentesReportados.Remove(reporte);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
