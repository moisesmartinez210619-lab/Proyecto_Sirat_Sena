﻿using System.Net;
using System.Net.Mail;

namespace SiratSena.Services
{
    public class EmailService
    {
        private readonly IConfiguration _config;

        public EmailService(IConfiguration config)
        {
            _config = config;
        }

        public async Task EnviarCorreo(string asunto, string mensaje)
        {
            var email = _config["EmailSettings:Email"];
            var password = _config["EmailSettings:Password"];
            var smtp = _config["EmailSettings:Smtp"];
            var puerto = int.Parse(_config["EmailSettings:Port"]);

            var client = new SmtpClient(smtp)
            {
                Port = puerto,
                Credentials = new NetworkCredential(email, password),
                EnableSsl = true
            };

            var mail = new MailMessage
            {
                From = new MailAddress(email),
                Subject = asunto,
                Body = mensaje,
                IsBodyHtml = false
            };

            // Destinatario = Administrador
            mail.To.Add("siratadmin@gmail.com");

            await client.SendMailAsync(mail);
        }
    }
}
