﻿using Microsoft.EntityFrameworkCore;
using SiratSena.Data;
using SiratSena.Models;

namespace SiratSena.Services
{
    public class InfoEducacionService
    {
        private readonly AppDbContext _context;

        public InfoEducacionService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<InfoEducacion>> GetAll()
        {
            return await _context.InfoEducacion.ToListAsync();
        }

        public async Task<InfoEducacion?> GetById(int id)
        {
            return await _context.InfoEducacion
                .FirstOrDefaultAsync(i => i.ID_INFO_EDUCACION == id);
        }

        public async Task<InfoEducacion> Create(InfoEducacion info)
        {
            _context.InfoEducacion.Add(info);
            await _context.SaveChangesAsync();
            return info;
        }

        public async Task<bool> Update(int id, InfoEducacion updated)
        {
            var info = await _context.InfoEducacion
                .FirstOrDefaultAsync(i => i.ID_INFO_EDUCACION == id);

            if (info == null)
                return false;

            info.Ficha = updated.Ficha;
            info.Nombre_de_la_ficha = updated.Nombre_de_la_ficha;
            info.Jornada = updated.Jornada;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> Delete(int id)
        {
            var info = await _context.InfoEducacion
                .FirstOrDefaultAsync(i => i.ID_INFO_EDUCACION == id);

            if (info == null)
                return false;

            _context.InfoEducacion.Remove(info);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
