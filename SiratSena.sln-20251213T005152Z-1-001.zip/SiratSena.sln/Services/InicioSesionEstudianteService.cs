﻿using Microsoft.EntityFrameworkCore;
using SiratSena.Data;
using SiratSena.Models;

namespace SiratSena.Services
{
    public class InicioSesionEstudianteService
    {
        private readonly AppDbContext _context;

        public InicioSesionEstudianteService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<InicioSesionEstudiante>> GetAll()
        {
            return await _context.InicioSesionEstudiante
                .Include(x => x.Estudiante)
                .ToListAsync();
        }

        public async Task<InicioSesionEstudiante?> GetById(int id)
        {
            return await _context.InicioSesionEstudiante
                .Include(x => x.Estudiante)
                .FirstOrDefaultAsync(x => x.ID_SESION_EST == id);
        }

        public async Task<InicioSesionEstudiante> Create(InicioSesionEstudiante sesion)
        {
            sesion.Fecha_Registro = DateTime.Now;
            sesion.Ultimo_Acceso = DateTime.Now;

            _context.InicioSesionEstudiante.Add(sesion);
            await _context.SaveChangesAsync();
            return sesion;
        }

        public async Task<bool> Update(int id, InicioSesionEstudiante updated)
        {
            var sesion = await _context.InicioSesionEstudiante
                .FirstOrDefaultAsync(x => x.ID_SESION_EST == id);

            if (sesion == null)
                return false;

            sesion.Correo = updated.Correo;
            sesion.Contrasena = updated.Contrasena;
            sesion.ID_ESTUDIANTE = updated.ID_ESTUDIANTE;
            sesion.Ultimo_Acceso = DateTime.Now;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> Delete(int id)
        {
            var sesion = await _context.InicioSesionEstudiante
                .FirstOrDefaultAsync(x => x.ID_SESION_EST == id);

            if (sesion == null)
                return false;

            _context.InicioSesionEstudiante.Remove(sesion);
            await _context.SaveChangesAsync();
            return true;
        }

        // LOGIN
        public async Task<Estudiante?> Login(string correo, string clave)
        {
            var sesion = await _context.InicioSesionEstudiante
                .FirstOrDefaultAsync(x => x.Correo == correo && x.Contrasena == clave);

            if (sesion == null)
                return null;

            return await _context.Estudiantes
                .Include(e => e.InfoEducacion)
                .FirstOrDefaultAsync(e => e.ID_ESTUDIANTE == sesion.ID_ESTUDIANTE);
        }
    }
}
