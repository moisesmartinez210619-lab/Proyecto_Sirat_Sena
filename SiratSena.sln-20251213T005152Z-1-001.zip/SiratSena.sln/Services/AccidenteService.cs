using Microsoft.EntityFrameworkCore;
using SiratSena.Data;
using SiratSena.Models;

namespace SiratSena.Services
{
    public class AccidenteService
    {
        private readonly AppDbContext _context;

        public AccidenteService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Accidente>> GetAll()
        {
            return await _context.Accidentes
                .Include(a => a.Estudiante)
                .Include(a => a.AccidentesReportados)
                .ToListAsync();
        }

        public async Task<Accidente?> GetById(int id)
        {
            return await _context.Accidentes
                .Include(a => a.Estudiante)
                .Include(a => a.AccidentesReportados)
                .FirstOrDefaultAsync(a => a.ID_ACCIDENTE == id);
        }

        public async Task<Accidente> Create(Accidente a)
        {
            _context.Accidentes.Add(a);
            await _context.SaveChangesAsync();
            return a;
        }

        public async Task<bool> Update(int id, Accidente updated)
        {
            var accidente = await _context.Accidentes
                .FirstOrDefaultAsync(a => a.ID_ACCIDENTE == id);

            if (accidente == null)
                return false;

            accidente.Fecha = updated.Fecha;
            accidente.Hora = updated.Hora;
            accidente.Descripcion = updated.Descripcion;
            accidente.Gravedad = updated.Gravedad;
            accidente.Imagen = updated.Imagen;
            accidente.ID_ESTUDIANTE = updated.ID_ESTUDIANTE;
            accidente.ID_ACCIDENTES_REPORTADOS = updated.ID_ACCIDENTES_REPORTADOS;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> Delete(int id)
        {
            var accidente = await _context.Accidentes
                .FirstOrDefaultAsync(a => a.ID_ACCIDENTE == id);

            if (accidente == null)
                return false;

            _context.Accidentes.Remove(accidente);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
