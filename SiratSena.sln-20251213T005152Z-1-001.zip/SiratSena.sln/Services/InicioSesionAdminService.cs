﻿using Microsoft.EntityFrameworkCore;
using SiratSena.Data;
using SiratSena.Models;

namespace SiratSena.Services
{
    public class InicioSesionAdminService
    {
        private readonly AppDbContext _context;

        public InicioSesionAdminService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<InicioSesionAdmin>> GetAll()
        {
            return await _context.InicioSesionAdmin
                .Include(a => a.Admin)
                .ToListAsync();
        }

        public async Task<InicioSesionAdmin?> GetById(int id)
        {
            return await _context.InicioSesionAdmin
                .Include(a => a.Admin)
                .FirstOrDefaultAsync(a => a.ID_SESION_ADMIN == id);
        }

        public async Task<InicioSesionAdmin> Create(InicioSesionAdmin sesion)
        {
            sesion.Fecha_Creacion = DateTime.Now;
            sesion.Ultimo_Acceso = DateTime.Now;

            _context.InicioSesionAdmin.Add(sesion);
            await _context.SaveChangesAsync();
            return sesion;
        }

        public async Task<bool> Update(int id, InicioSesionAdmin updated)
        {
            var sesion = await _context.InicioSesionAdmin
                .FirstOrDefaultAsync(a => a.ID_SESION_ADMIN == id);

            if (sesion == null)
                return false;

            sesion.Correo = updated.Correo;
            sesion.Contrasena = updated.Contrasena;
            sesion.ID_ADMIN = updated.ID_ADMIN;
            sesion.Ultimo_Acceso = DateTime.Now;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> Delete(int id)
        {
            var sesion = await _context.InicioSesionAdmin
                .FirstOrDefaultAsync(a => a.ID_SESION_ADMIN == id);

            if (sesion == null)
                return false;

            _context.InicioSesionAdmin.Remove(sesion);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Admin?> Login(string correo, string clave)
        {
            var sesion = await _context.InicioSesionAdmin
                .FirstOrDefaultAsync(s => s.Correo == correo && s.Contrasena == clave);

            if (sesion == null)
                return null;

            return await _context.Admins
                .FirstOrDefaultAsync(a => a.ID_ADMIN == sesion.ID_ADMIN);
        }
    }
}
