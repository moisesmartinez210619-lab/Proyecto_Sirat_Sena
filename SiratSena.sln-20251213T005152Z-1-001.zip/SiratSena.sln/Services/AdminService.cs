using Microsoft.EntityFrameworkCore;
using SiratSena.Data;
using SiratSena.Models;

namespace SiratSena.Services
{
    public class AdminService
    {
        private readonly AppDbContext _context;

        public AdminService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Admin>> GetAll()
        {
            return await _context.Admins.ToListAsync();
        }

        public async Task<Admin?> GetById(int id)
        {
            return await _context.Admins.FirstOrDefaultAsync(a => a.ID_ADMIN == id);
        }

        public async Task<Admin> Create(Admin admin)
        {
            _context.Admins.Add(admin);
            await _context.SaveChangesAsync();
            return admin;
        }

        public async Task<bool> Update(int id, Admin updated)
        {
            var admin = await _context.Admins.FirstOrDefaultAsync(a => a.ID_ADMIN == id);

            if (admin == null)
                return false;

            admin.Nombre_Admin = updated.Nombre_Admin;
            admin.Correo = updated.Correo;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> Delete(int id)
        {
            var admin = await _context.Admins.FirstOrDefaultAsync(a => a.ID_ADMIN == id);

            if (admin == null)
                return false;

            _context.Admins.Remove(admin);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
