﻿using Microsoft.AspNetCore.Mvc;
using SiratSena.Models;
using SiratSena.Services;

namespace SiratSena.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InicioSesionAdminController : ControllerBase
    {
        private readonly InicioSesionAdminService _service;

        public InicioSesionAdminController(InicioSesionAdminService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _service.GetAll());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var s = await _service.GetById(id);
            if (s == null) return NotFound();
            return Ok(s);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] InicioSesionAdmin sesion)
        {
            var creado = await _service.Create(sesion);
            return Ok(creado);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] InicioSesionAdmin sesion)
        {
            var ok = await _service.Update(id, sesion);
            if (!ok) return NotFound();
            return Ok(true);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var ok = await _service.Delete(id);
            if (!ok) return NotFound();
            return Ok(true);
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(string correo, string clave)
        {
            var admin = await _service.Login(correo, clave);
            if (admin == null) return Unauthorized("Credenciales incorrectas");
            return Ok(admin);
        }
    }
}
