﻿using Microsoft.AspNetCore.Mvc;
using SiratSena.Models;
using SiratSena.Services;

namespace SiratSena.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccidentesReportadosController : ControllerBase
    {
        private readonly AccidentesReportadosService _service;

        public AccidentesReportadosController(AccidentesReportadosService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _service.GetAll());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var reporte = await _service.GetById(id);
            if (reporte == null) return NotFound();
            return Ok(reporte);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] AccidentesReportados reporte)
        {
            var creado = await _service.Create(reporte);
            return Ok(creado);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] AccidentesReportados reporte)
        {
            var ok = await _service.Update(id, reporte);
            if (!ok) return NotFound();
            return Ok(true);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var ok = await _service.Delete(id);
            if (!ok) return NotFound();
            return Ok(true);
        }
    }
}
