using Microsoft.AspNetCore.Mvc;
using SiratSena.Models;
using SiratSena.Services;

namespace SiratSena.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccidentesController : ControllerBase
    {
        private readonly AccidenteService _service;

        public AccidentesController(AccidenteService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return Ok(await _service.GetAll());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var resultado = await _service.GetById(id);
            if (resultado == null) return NotFound();
            return Ok(resultado);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Accidente a)
        {
            var nuevo = await _service.Create(a);
            return Ok(nuevo);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Accidente a)
        {
            var actualizado = await _service.Update(id, a);
            if (!actualizado) return NotFound();
            return Ok(actualizado);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var eliminado = await _service.Delete(id);
            if (!eliminado) return NotFound();
            return Ok(true);
        }
    }
}
