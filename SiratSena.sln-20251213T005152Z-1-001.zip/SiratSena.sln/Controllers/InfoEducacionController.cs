﻿using Microsoft.AspNetCore.Mvc;
using SiratSena.Models;
using SiratSena.Services;

namespace SiratSena.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InfoEducacionController : ControllerBase
    {
        private readonly InfoEducacionService _service;

        public InfoEducacionController(InfoEducacionService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _service.GetAll());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var info = await _service.GetById(id);
            if (info == null) return NotFound();
            return Ok(info);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] InfoEducacion info)
        {
            var creado = await _service.Create(info);
            return Ok(creado);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] InfoEducacion info)
        {
            var ok = await _service.Update(id, info);
            if (!ok) return NotFound();
            return Ok(true);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var ok = await _service.Delete(id);
            if (!ok) return NotFound();
            return Ok(true);
        }
    }
}
