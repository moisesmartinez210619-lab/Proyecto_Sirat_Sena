﻿using Microsoft.AspNetCore.Mvc;
using SiratSena.Models;
using SiratSena.Services;

namespace SiratSena.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InicioSesionEstudianteController : ControllerBase
    {
        private readonly InicioSesionEstudianteService _service;

        public InicioSesionEstudianteController(InicioSesionEstudianteService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _service.GetAll());
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int id)
        {
            var sesion = await _service.GetById(id);
            if (sesion == null) return NotFound();
            return Ok(sesion);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] InicioSesionEstudiante sesion)
        {
            var creado = await _service.Create(sesion);
            return Ok(creado);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] InicioSesionEstudiante sesion)
        {
            var ok = await _service.Update(id, sesion);
            if (!ok) return NotFound();
            return Ok(true);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var ok = await _service.Delete(id);
            if (!ok) return NotFound();
            return Ok(true);
        }

        // 🔥 Login
        [HttpPost("login")]
        public async Task<IActionResult> Login(string correo, string clave)
        {
            var estudiante = await _service.Login(correo, clave);

            if (estudiante == null)
                return Unauthorized("Credenciales incorrectas");

            return Ok(estudiante);
        }
    }
}
