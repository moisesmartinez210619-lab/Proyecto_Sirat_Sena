using Microsoft.AspNetCore.Mvc;
using SiratSena.Services;

namespace SiratSena.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AuthService _authService;

        public AuthController(AuthService authService)
        {
            _authService = authService;
        }

        // ============================================================
        //  LOGIN ESTUDIANTE
        // ============================================================
        [HttpPost("login-estudiante")]
        public async Task<IActionResult> LoginEstudiante([FromBody] LoginRequest request)
        {
            var resultado = await _authService.LoginEstudiante(request.Correo, request.Contrasena);

            if (resultado == null)
                return Unauthorized(new { mensaje = "Correo o contrase�a incorrectos" });

            return Ok(new
            {
                mensaje = "Inicio de sesi�n exitoso",
                datos = resultado,
                tipo = "estudiante"
            });
        }

        // ============================================================
        //  LOGIN ADMIN
        // ============================================================
        [HttpPost("login-admin")]
        public async Task<IActionResult> LoginAdmin([FromBody] LoginRequest request)
        {
            var resultado = await _authService.LoginAdmin(request.Correo, request.Contrasena);

            if (resultado == null)
                return Unauthorized(new { mensaje = "Correo o contrase�a incorrectos" });

            return Ok(new
            {
                mensaje = "Inicio de sesi�n exitoso",
                datos = resultado,
                tipo = "admin"
            });
        }

        // ============================================================
        //  REGISTRO ESTUDIANTE
        // ============================================================
        [HttpPost("registrar-estudiante")]
        public async Task<IActionResult> Registrar([FromBody] RegistroRequest request)
        {
            var creado = await _authService.RegistrarEstudiante(
                request.Correo,
                request.Contrasena,
                request.Nombre,
                request.Apellido
            );

            if (!creado)
                return BadRequest(new { mensaje = "El correo ya est� registrado" });

            return Ok(new { mensaje = "Registro exitoso" });
        }
    }

    // ============================================================
    //  CLASES PARA RECIBIR DATOS DEL FRONT
    // ============================================================

    public class LoginRequest
    {
        public string Correo { get; set; } = string.Empty;
        public string Contrasena { get; set; } = string.Empty;
    }

    public class RegistroRequest
    {
        public string Nombre { get; set; } = string.Empty;
        public string Apellido { get; set; } = string.Empty;
        public string Correo { get; set; } = string.Empty;
        public string Contrasena { get; set; } = string.Empty;
    }
}
