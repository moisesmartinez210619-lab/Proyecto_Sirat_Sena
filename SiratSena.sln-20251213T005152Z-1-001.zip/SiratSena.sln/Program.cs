﻿using Microsoft.EntityFrameworkCore;
using SiratSena.Data;
using SiratSena.Services;

var builder = WebApplication.CreateBuilder(args);

// 🔥 0. HABILITAR CORS PARA QUE EL FRONT PUEDA HABLAR CON EL BACK
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// 1. Conexión con SQL Server
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
);

// 2. Servicios
builder.Services.AddScoped<EstudianteService>();
builder.Services.AddScoped<AccidenteService>();
builder.Services.AddScoped<AdminService>();
builder.Services.AddScoped<AuthService>();

// 3. Controllers + Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// 4. Swagger (solo en desarrollo)
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// 🔥 5. ACTIVAR CORS ANTES DE MAPEAR CONTROLADORES
app.UseCors("AllowAll");

// 🔥 6. ARCHIVOS DEL FRONTEND (Habilitar HTML, CSS y JS)
app.UseDefaultFiles();  // busca index.html automáticamente
app.UseStaticFiles();   // permite servir wwwroot

// 7. Middleware básico
app.UseHttpsRedirection();
app.UseAuthorization();

// 8. Controladores
app.MapControllers();

app.Run();
