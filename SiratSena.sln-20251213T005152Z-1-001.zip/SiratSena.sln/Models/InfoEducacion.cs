using System.ComponentModel.DataAnnotations;

namespace SiratSena.Models
{
    public class InfoEducacion
    {
        [Key]
        public int ID_INFO_EDUCACION { get; set; }
        public string Ficha { get; set; }
        public string Nombre_de_la_ficha { get; set; }
        public string Jornada { get; set; }
    }
}
