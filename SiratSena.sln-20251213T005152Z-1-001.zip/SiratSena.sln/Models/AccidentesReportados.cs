﻿using System.ComponentModel.DataAnnotations;

namespace SiratSena.Models
{
    public class AccidentesReportados
    {
        [Key]   // ← ESTO ES OBLIGATORIO
        public int ID_ACCIDENTES_REPORTADOS { get; set; }

        [Required]
        public string Accidente_Reporte { get; set; }
    }
}
