﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SiratSena.Models
{
    public class Accidente
    {
        [Key]  // ← NECESARIO
        public int ID_ACCIDENTE { get; set; }

        public DateTime Fecha { get; set; }

        public TimeSpan Hora { get; set; }

        [Required]
        public string Descripcion { get; set; }

        [Required]
        public string Gravedad { get; set; }

        public string Imagen { get; set; }

        [ForeignKey("Estudiante")]
        public int ID_ESTUDIANTE { get; set; }
        public Estudiante Estudiante { get; set; }

        [ForeignKey("AccidentesReportados")]
        public int ID_ACCIDENTES_REPORTADOS { get; set; }
        public AccidentesReportados AccidentesReportados { get; set; }
    }
}
