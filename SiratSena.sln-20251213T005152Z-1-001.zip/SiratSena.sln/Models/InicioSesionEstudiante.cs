using System;
using System.ComponentModel.DataAnnotations;

namespace SiratSena.Models
{
    public class InicioSesionEstudiante
    {
        [Key]
        public int ID_SESION_EST { get; set; }
        public string Correo { get; set; }
        public string Contrasena { get; set; }
        public DateTime Fecha_Registro { get; set; }
        public DateTime Ultimo_Acceso { get; set; }
        public int ID_ESTUDIANTE { get; set; }
        public Estudiante Estudiante { get; set; }
    }
}
