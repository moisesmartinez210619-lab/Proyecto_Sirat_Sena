﻿namespace SiratSena.Models.Dtos
{
    public class RegistroEstudianteDto
    {
        public string Correo { get; set; }
        public string Contrasena { get; set; }
        public string Nombre { get; set; } = "Sin nombre";
        public string Apellido { get; set; } = "Sin apellido";
    }
}
