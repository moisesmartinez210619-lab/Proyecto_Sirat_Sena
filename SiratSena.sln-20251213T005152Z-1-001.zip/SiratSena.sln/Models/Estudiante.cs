using System.ComponentModel.DataAnnotations;

namespace SiratSena.Models
{
    public class Estudiante
    {
        [Key]
        public int ID_ESTUDIANTE { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Correo { get; set; }
        public int ID_INFO_EDUCACION { get; set; }
        public InfoEducacion InfoEducacion { get; set; }
    }
}
