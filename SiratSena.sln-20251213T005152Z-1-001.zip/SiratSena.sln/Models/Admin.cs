﻿using System.ComponentModel.DataAnnotations;

namespace SiratSena.Models
{
    public class Admin
    {
        [Key]   // ← Obligatorio
        public int ID_ADMIN { get; set; }

        [Required]
        public string Nombre_Admin { get; set; }

        [Required]
        public string Correo { get; set; }
    }
}
