using System;
using System.ComponentModel.DataAnnotations;

namespace SiratSena.Models
{
    public class InicioSesionAdmin
    {
        [Key]
        public int ID_SESION_ADMIN { get; set; }
        public string Correo { get; set; }
        public string Contrasena { get; set; }
        public DateTime Fecha_Creacion { get; set; }
        public DateTime Ultimo_Acceso { get; set; }
        public int ID_ADMIN { get; set; }
        public Admin Admin { get; set; }
    }
}
