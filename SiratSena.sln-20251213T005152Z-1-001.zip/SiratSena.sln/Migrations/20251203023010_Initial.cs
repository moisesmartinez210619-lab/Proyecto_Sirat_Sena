﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace SiratSena.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AccidentesReportados",
                columns: table => new
                {
                    ID_ACCIDENTES_REPORTADOS = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Accidente_Reporte = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AccidentesReportados", x => x.ID_ACCIDENTES_REPORTADOS);
                });

            migrationBuilder.CreateTable(
                name: "Admins",
                columns: table => new
                {
                    ID_ADMIN = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre_Admin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Correo = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Admins", x => x.ID_ADMIN);
                });

            migrationBuilder.CreateTable(
                name: "InfoEducacion",
                columns: table => new
                {
                    ID_INFO_EDUCACION = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Ficha = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Nombre_de_la_ficha = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Jornada = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InfoEducacion", x => x.ID_INFO_EDUCACION);
                });

            migrationBuilder.CreateTable(
                name: "InicioSesionAdmin",
                columns: table => new
                {
                    ID_SESION_ADMIN = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Correo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Contrasena = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Fecha_Creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Ultimo_Acceso = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ID_ADMIN = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InicioSesionAdmin", x => x.ID_SESION_ADMIN);
                    table.ForeignKey(
                        name: "FK_InicioSesionAdmin_Admins_ID_ADMIN",
                        column: x => x.ID_ADMIN,
                        principalTable: "Admins",
                        principalColumn: "ID_ADMIN",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Estudiantes",
                columns: table => new
                {
                    ID_ESTUDIANTE = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Apellido = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Correo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ID_INFO_EDUCACION = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Estudiantes", x => x.ID_ESTUDIANTE);
                    table.ForeignKey(
                        name: "FK_Estudiantes_InfoEducacion_ID_INFO_EDUCACION",
                        column: x => x.ID_INFO_EDUCACION,
                        principalTable: "InfoEducacion",
                        principalColumn: "ID_INFO_EDUCACION",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "Accidentes",
                columns: table => new
                {
                    ID_ACCIDENTE = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Hora = table.Column<TimeSpan>(type: "time", nullable: false),
                    Descripcion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Gravedad = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Imagen = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ID_ESTUDIANTE = table.Column<int>(type: "int", nullable: false),
                    ID_ACCIDENTES_REPORTADOS = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Accidentes", x => x.ID_ACCIDENTE);
                    table.ForeignKey(
                        name: "FK_Accidentes_AccidentesReportados_ID_ACCIDENTES_REPORTADOS",
                        column: x => x.ID_ACCIDENTES_REPORTADOS,
                        principalTable: "AccidentesReportados",
                        principalColumn: "ID_ACCIDENTES_REPORTADOS",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "FK_Accidentes_Estudiantes_ID_ESTUDIANTE",
                        column: x => x.ID_ESTUDIANTE,
                        principalTable: "Estudiantes",
                        principalColumn: "ID_ESTUDIANTE",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "InicioSesionEstudiante",
                columns: table => new
                {
                    ID_SESION_EST = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Correo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Contrasena = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Fecha_Registro = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Ultimo_Acceso = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ID_ESTUDIANTE = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InicioSesionEstudiante", x => x.ID_SESION_EST);
                    table.ForeignKey(
                        name: "FK_InicioSesionEstudiante_Estudiantes_ID_ESTUDIANTE",
                        column: x => x.ID_ESTUDIANTE,
                        principalTable: "Estudiantes",
                        principalColumn: "ID_ESTUDIANTE",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Accidentes_ID_ACCIDENTES_REPORTADOS",
                table: "Accidentes",
                column: "ID_ACCIDENTES_REPORTADOS");

            migrationBuilder.CreateIndex(
                name: "IX_Accidentes_ID_ESTUDIANTE",
                table: "Accidentes",
                column: "ID_ESTUDIANTE");

            migrationBuilder.CreateIndex(
                name: "IX_Estudiantes_ID_INFO_EDUCACION",
                table: "Estudiantes",
                column: "ID_INFO_EDUCACION");

            migrationBuilder.CreateIndex(
                name: "IX_InicioSesionAdmin_ID_ADMIN",
                table: "InicioSesionAdmin",
                column: "ID_ADMIN");

            migrationBuilder.CreateIndex(
                name: "IX_InicioSesionEstudiante_ID_ESTUDIANTE",
                table: "InicioSesionEstudiante",
                column: "ID_ESTUDIANTE");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Accidentes");

            migrationBuilder.DropTable(
                name: "InicioSesionAdmin");

            migrationBuilder.DropTable(
                name: "InicioSesionEstudiante");

            migrationBuilder.DropTable(
                name: "AccidentesReportados");

            migrationBuilder.DropTable(
                name: "Admins");

            migrationBuilder.DropTable(
                name: "Estudiantes");

            migrationBuilder.DropTable(
                name: "InfoEducacion");
        }
    }
}
