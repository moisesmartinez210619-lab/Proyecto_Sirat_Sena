# SiratSena - Backend (.NET 9)

Proyecto base de API Web en .NET 9 para el sistema de reporte de accidentes.

## Instrucciones rápidas

1. Abrir la solución `SiratSena.csproj` en Visual Studio 2022 (con .NET 9 instalado).
2. Actualizar la cadena de conexión en `appsettings.json`.
3. Abrir **Package Manager Console** y ejecutar:
   - `dotnet restore`
   - `Add-Migration InitialCreate`
   - `Update-Database`
4. Ejecutar la API (F5). Swagger estará disponible en `/swagger`.

## Contenido
- Models: entidades (Estudiante, Accidente, Admin, etc.)
- Data: AppDbContext
- Services: servicios simples para lógica
- Controllers: endpoints REST básicos
