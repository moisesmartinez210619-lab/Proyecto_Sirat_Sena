﻿using Microsoft.EntityFrameworkCore;
using SiratSena.Models;

namespace SiratSena.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<Estudiante> Estudiantes { get; set; }
        public DbSet<InfoEducacion> InfoEducacion { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<Accidente> Accidentes { get; set; }
        public DbSet<AccidentesReportados> AccidentesReportados { get; set; }
        public DbSet<InicioSesionAdmin> InicioSesionAdmin { get; set; }
        public DbSet<InicioSesionEstudiante> InicioSesionEstudiante { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // === ESTUDIANTE ===
            modelBuilder.Entity<Estudiante>()
                .HasOne(e => e.InfoEducacion)
                .WithMany()
                .HasForeignKey(e => e.ID_INFO_EDUCACION)
                .OnDelete(DeleteBehavior.SetNull);

            // === ACCIDENTE ===
            modelBuilder.Entity<Accidente>()
                .HasOne(a => a.Estudiante)
                .WithMany()
                .HasForeignKey(a => a.ID_ESTUDIANTE)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<Accidente>()
                .HasOne(a => a.AccidentesReportados)
                .WithMany()
                .HasForeignKey(a => a.ID_ACCIDENTES_REPORTADOS)
                .OnDelete(DeleteBehavior.SetNull);

            // === Inicio Sesion Admin ===
            modelBuilder.Entity<InicioSesionAdmin>()
                .HasOne(i => i.Admin)
                .WithMany()
                .HasForeignKey(i => i.ID_ADMIN)
                .OnDelete(DeleteBehavior.Cascade);

            // === Inicio Sesion Estudiante ===
            modelBuilder.Entity<InicioSesionEstudiante>()
                .HasOne(i => i.Estudiante)
                .WithMany()
                .HasForeignKey(i => i.ID_ESTUDIANTE)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}

